<?php


namespace App;


class Base
{


}

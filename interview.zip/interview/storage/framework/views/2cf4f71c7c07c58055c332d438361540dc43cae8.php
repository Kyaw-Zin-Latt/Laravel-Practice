<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH C:\Users\Kyaw Zin Latt\Desktop\Laravel\interview\resources\views/components/menu-title.blade.php ENDPATH**/ ?>
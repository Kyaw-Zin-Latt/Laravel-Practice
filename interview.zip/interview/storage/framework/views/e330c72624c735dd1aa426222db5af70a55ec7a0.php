<h1>Welcome</h1>
<a href="<?php echo e(route("login")); ?>">Login</a>
<?php /**PATH C:\Users\Kyaw Zin Latt\Desktop\Laravel\interview\frontend-preparation(laravel7)\resources\views/welcome.blade.php ENDPATH**/ ?>
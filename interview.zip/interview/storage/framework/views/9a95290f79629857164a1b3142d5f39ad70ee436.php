<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
</head>
<body>

    <div class="container">
        <div class="row text-center d-flex align-items-center" style="height: 100vh;">
            <div class="col-12">
                <h1 class="text-primary">Welcome From My Shop Sir😘😘😘</h1>
                <p>Please Login Here</p>
                <a href="<?php echo e(route("login")); ?>" class="btn btn-outline-primary">Login</a>
            </div>
        </div>
    </div>

</body>
</html>


<?php /**PATH C:\Users\Kyaw Zin Latt\Desktop\Laravel\interview\resources\views/welcome.blade.php ENDPATH**/ ?>
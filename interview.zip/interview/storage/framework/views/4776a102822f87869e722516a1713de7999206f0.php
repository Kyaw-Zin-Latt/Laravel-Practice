<li class="menu-item">
    <a href="<?php echo e($link); ?>" class="menu-item-link <?php echo e(Request::url() == $link ? "active" : ""); ?>">
        <span class="text-uppercase">
            <i class="fa-fw <?php echo e($class); ?>"></i>
            <?php echo e($name); ?>

        </span>
        <span class="badge badge-pill bg-white shadow-sm text-primary"><?php echo e($counter); ?></span>
    </a>
</li>
<?php /**PATH C:\Users\Kyaw Zin Latt\Desktop\Laravel\interview\resources\views/components/menu-item.blade.php ENDPATH**/ ?>
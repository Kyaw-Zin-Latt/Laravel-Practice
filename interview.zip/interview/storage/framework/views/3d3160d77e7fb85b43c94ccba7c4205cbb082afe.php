<?php $__env->startSection("title"); ?> Category <?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bread-crumb','data' => []]); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item active" aria-current="page">Category</li>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="">
        <?php if(session("message")): ?>
            <p class="alert alert-success"><?php echo session('message'); ?></p>
        <?php endif; ?>
    </div>
    <table class="table table-bordered table-hover">
        <thead>
        <tr>
            <th>No</th>
            <th>Category Name</th>
            <th>Photo</th>
            <th>Icon</th>
            <th>Control</th>
            <th>Publish</th>
            <th>Date / Time</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e(Str::title(Str::substr($category->title, 0, 25))); ?> <?php echo e(Str::length($category->title) > 26 ? "..." : ""); ?></td>
            <td>
                <img src="<?php echo e(asset("storage/category/photo/".$category->category_photo)); ?>" class="rounded" style="width: 50px"; alt="">
            </td>
            <td>
                <img src="<?php echo e(asset("storage/category/icon/".$category->category_icon)); ?>" class="rounded" style="width: 50px"; alt="">
            </td>
            <td>
                <form action="<?php echo e(route("category.destroy",$category->id)); ?>" class="d-inline-block" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("delete"); ?>
                    <button class="btn btn-outline-danger"><i class="fas fa-trash-alt fa-fw"></i></button>
                </form>
                <a href="<?php echo e(route("category.edit",$category->id)); ?>" class="btn btn-outline-info"><i class="fas fa-edit fa-fw"></i></a>
            </td>
            <td>
                <?php if($category->publish == "0"): ?>
                    <button class="btn btn-danger">No</button>
                <?php else: ?>
                    <button class="btn btn-success">Yes</button>
                <?php endif; ?>
            </td>
            <td>
                <small>
                    <i class="fas fa-calendar-alt"></i>
                    <?php echo e($category->created_at->format('d M Y')); ?>

                    <br>
                    <i class="fas fa-clock"></i>
                    <?php echo e($category->created_at->format('h : i a')); ?>

                </small>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7">
                    <p class="text-center mb-0 font-weight-bolder">There is no Category😢😢😢.</p>
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-between align-items-center">
        <?php echo e($categories->links()); ?>

        <h4 class="font-weight-bolder">Total : <?php echo e($categories->total()); ?></h4>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kyaw Zin Latt\Desktop\Laravel\interview\resources\views/category/index.blade.php ENDPATH**/ ?>